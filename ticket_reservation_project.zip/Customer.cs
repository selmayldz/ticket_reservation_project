﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prolab2
{
    public class Customer
    {
        public string Nereden { get; set; }
        public string Nereye { get; set; }
        public string Ad { get; set; }
        public DateTime BiletTarihi { get; set; }

    }

}
